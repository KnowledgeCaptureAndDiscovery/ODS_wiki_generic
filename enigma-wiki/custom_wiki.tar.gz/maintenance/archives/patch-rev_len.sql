ALTER TABLE /*$wgDBprefix*/revision
  ADD rev_len INT UNSIGNED;

