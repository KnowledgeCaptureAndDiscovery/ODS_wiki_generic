-- Added early in 1.5 alpha development, removed 2005-04-25

ALTER TABLE /*$wgDBprefix*/user DROP COLUMN user_emailauthenticationtimestamp;
