ALTER TABLE /*$wgDBprefix*/page
  ADD page_content_model varbinary(32) DEFAULT NULL;
