CREATE INDEX /*i*/type_action ON /*_*/logging(log_type, log_action, log_timestamp);
