ALTER TABLE /*$wgDBprefix*/uploadstash
  ADD COLUMN us_props blob;
