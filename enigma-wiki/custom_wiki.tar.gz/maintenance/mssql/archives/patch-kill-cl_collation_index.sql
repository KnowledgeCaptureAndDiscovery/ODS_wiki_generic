--
-- Kill cl_collation index.
-- @since 1.27
--

DROP INDEX /*i*/cl_collation ON /*_*/categorylinks;

