<?php
// B/C alias
require_once ( __DIR__ . '/getReplicaServer.php' );
